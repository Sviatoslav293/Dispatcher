namespace AircraftSimulator.Core;

public interface IAircraftSimulationContext
{
    AircraftState State { get; }
    IReadOnlyList<Waypoint> Route { get; }
    Waypoint? CurrentWaypoint { get; }
    double? DesiredHeadingDegrees { get; set; }
    double? DesiredSpeedKmh { get; set; }
    bool AdvanceToNextWaypoint();
}

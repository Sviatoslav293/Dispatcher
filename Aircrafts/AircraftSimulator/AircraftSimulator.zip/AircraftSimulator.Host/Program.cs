using AircraftSimulator.Core;
using AircraftSimulator.Host;
using AircraftSimulator.Plugins;

var builder = Host.CreateApplicationBuilder(args);

var aircraftConfigurationPath = builder.Configuration["AircraftConfiguration:Path"] ?? "aircraft.json";
var resolvedConfigurationPath = Path.GetFullPath(aircraftConfigurationPath, builder.Environment.ContentRootPath);

builder.Services.AddSingleton<IAircraftConfigurationSource>(new LocalConfigurationSource(resolvedConfigurationPath));
builder.Services.AddSingleton<ISimulationClock, SystemSimulationClock>();
builder.Services.AddSingleton<ITelemetryPublisher, LoggerTelemetryPublisher>();
var movementOptions = builder.Configuration.GetSection("Movement").Get<MovementOptions>() ?? new MovementOptions();
var navigationOptions = builder.Configuration.GetSection("Navigation").Get<NavigationOptions>() ?? new NavigationOptions();
builder.Services.AddSingleton(movementOptions);
builder.Services.AddSingleton(navigationOptions);
builder.Services.AddSingleton<IAircraftModule>(services => new NavigationModule(
    services.GetRequiredService<NavigationOptions>(),
    services.GetRequiredService<MovementOptions>()));
builder.Services.AddSingleton<IAircraftModule>(services => new MovementModule(services.GetRequiredService<MovementOptions>()));
builder.Services.AddSingleton<IAircraftModule, TelemetryModule>();
builder.Services.AddSingleton<IAircraftSimulator, AircraftSimulator.Core.AircraftSimulator>();
builder.Services.AddHostedService<Worker>();

var host = builder.Build();
host.Run();

using System.Diagnostics;
using AircraftSimulator.Core;

namespace AircraftSimulator.Plugins;

public sealed class SystemSimulationClock : ISimulationClock
{
    private readonly Stopwatch _stopwatch = Stopwatch.StartNew();
    private TimeSpan _previousElapsed;

    public async ValueTask<TimeSpan> WaitForNextTickAsync(TimeSpan updateInterval, CancellationToken cancellationToken)
    {
        await Task.Delay(updateInterval, cancellationToken);
        var elapsed = _stopwatch.Elapsed;
        var deltaTime = elapsed - _previousElapsed;
        _previousElapsed = elapsed;
        return deltaTime;
    }
}
